package gnb

import (
	"encoding/hex"
	"fmt"
	"net"

	"github.com/free-ran-ue/free-ran-ue/v2/constant"
	"github.com/free5gc/ngap/ie"
)

func setupUplinkTeid(transfer ie.PDUSessionResourceSetupRequestTransfer) []byte {
	if transfer.ProtocolIEs != nil {
		for _, item := range transfer.ProtocolIEs.List {
			if item.ULNGUUPTNLInformation != nil {
				if tunnel, ok := item.ULNGUUPTNLInformation.Choice.(*ie.GTPTunnel); ok && tunnel.GTPTEID != nil {
					return tunnel.GTPTEID.Value
				}
			}
		}
	}
	return nil
}

// A second session has its own data-plane state and does not own an N1 connection.
func (g *Gnb) registerSecondSession(imsi string, ulTeid []byte, server *net.UDPConn) *XnUe {
	session := NewXnUe(imsi, g.teidGenerator.AllocateTeid(), nil)
	session.SetUlTeid(ulTeid)
	session.dataPlaneServer = server
	g.xnUeConns.Store(session, struct{}{})
	g.dlTeidToUe.Store(hex.EncodeToString(session.GetDlTeid()), session)
	g.imsiTodlTeidAndUeType.Store(imsi+constant.SecondPduSessionSuffix, dlTeidAndUeType{
		dlTeid: session.GetDlTeid(), ueType: constant.UE_TYPE_XN,
	})
	return session
}

func (g *Gnb) secondSessionTunnel(ranUe *RanUe, transfer ie.PDUSessionResourceSetupRequestTransfer, request []byte) ([]byte, string, error) {
	imsi := ranUe.GetMobileIdentityIMSI()
	if !g.staticNrdc {
		ulTeid := setupUplinkTeid(transfer)
		if len(ulTeid) != 4 {
			return nil, "", fmt.Errorf("second PDU session is missing its uplink TEID")
		}
		session := g.registerSecondSession(imsi, ulTeid, g.secondDataPlaneServer)
		return session.GetDlTeid(), g.ranN3Ip, nil
	}

	item, err := g.xnPduSessionResourceSetupRequestTransfer(imsi, request)
	if err != nil {
		return nil, "", err
	}
	if item.QosFlowPerTNLInformation == nil || item.QosFlowPerTNLInformation.UPTransportLayerInformation == nil {
		return nil, "", fmt.Errorf("secondary RAN returned no downlink tunnel")
	}
	tunnel, ok := item.QosFlowPerTNLInformation.UPTransportLayerInformation.Choice.(*ie.GTPTunnel)
	if !ok || tunnel.GTPTEID == nil || tunnel.TransportLayerAddress == nil {
		return nil, "", fmt.Errorf("secondary RAN returned invalid downlink tunnel")
	}
	return tunnel.GTPTEID.Value, net.IP(tunnel.TransportLayerAddress.Value.Bytes).String(), nil
}
