package ue

import (
	"fmt"
	"io"
	"net"

	"github.com/free-ran-ue/free-ran-ue/v2/constant"
	"github.com/free-ran-ue/util"
)

func (u *Ue) startSecondDataPlane() error {
	if u.secondSession.ueIp == "" {
		return fmt.Errorf("second PDU session did not receive an IPv4 address")
	}

	ip, port, localIP := u.ranDataPlaneIp, u.secondDataPlanePort, u.localDataPlaneIp
	if u.isNrdcEnabled() {
		ip, port, localIP = u.nrdc.dcRanDataPlane.ip, u.nrdc.dcRanDataPlane.port, u.nrdc.dcLocalDataPlaneIp
	}

	conn, err := util.UdpDialWithOptionalLocalAddress(ip, port, localIP)
	if err != nil {
		return fmt.Errorf("dial second PDU session: %w", err)
	}
	initial := constant.UE_DATA_PLANE_INITIAL_PACKET + " " + constant.UE_IMSI_PREFIX + u.supi + constant.SecondPduSessionSuffix
	if _, err := conn.Write([]byte(initial)); err != nil {
		_ = conn.Close()
		return fmt.Errorf("announce second PDU session: %w", err)
	}
	u.secondConn = conn
	if u.ignoreSetupTunnel {
		return nil
	}

	tun, err := bringUpUeTunnelDevice(u.secondTunnelName, u.secondSession.ueIp)
	if err != nil {
		u.stopSecondDataPlane()
		return fmt.Errorf("configure second TUN: %w", err)
	}
	u.secondTunnel = tun

	// Keep each packet on the socket and TUN belonging to its session.
	u.secondWorkers.Add(2)
	go u.copySecondSessionPackets(conn, tun)
	go u.copySecondSessionPackets(tun, conn)
	u.TunLog.Infof("PDU session %d uses %s (%s) via %s", constant.SecondPduSessionID,
		u.secondTunnelName, u.secondSession.ueIp, net.JoinHostPort(ip, fmt.Sprint(port)))
	return nil
}

func (u *Ue) copySecondSessionPackets(dst io.Writer, src io.Reader) {
	defer u.secondWorkers.Done()
	buffer := make([]byte, 4096)
	for {
		n, err := src.Read(buffer)
		if err != nil {
			return
		}
		if n == 0 || buffer[0]>>4 != 4 {
			continue
		}
		if _, err := dst.Write(buffer[:n]); err != nil {
			u.TunLog.Debugf("Second PDU session packet forwarding stopped: %v", err)
			return
		}
	}
}

func (u *Ue) stopSecondDataPlane() {
	if u.secondConn == nil {
		return
	}
	_ = u.secondConn.Close()
	if u.secondTunnel != nil {
		_ = u.secondTunnel.Close()
	}
	u.secondWorkers.Wait()
}
